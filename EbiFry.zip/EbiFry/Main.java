/**
 * Main クラスはアプリケーションのエントリーポイントを提供する。
 * 
 * @Author: 
 */
public class Main {
    /**
     * アプリケーションのエントリーポイント。
     * 
     * @param args コマンドライン引数
     */
    public static void main(String[] args) {
        // モデル、ビュー、コントローラーのインスタンスを作成
        EbiFryClockModel model = new EbiFryClockModel();
        EbiFryClockView view = new EbiFryClockView(model);
        EbiFryClockController controller = new EbiFryClockController(model, view);
        
        // 時計の表示を開始
        controller.startClock();
    }
}
