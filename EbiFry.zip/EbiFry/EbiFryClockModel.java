import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import javax.imageio.ImageIO;

/**
 * EbiFryClockModel クラスはデータとロジックを担当する。
 * 
 * @Author:
 */
public class EbiFryClockModel {

    /**
     * エビフライの画像ファイル名
     */
    public static final String EBIFRY_IMAGE_FILENAMES = "food_ebi_fry.png";

    

    /**
     * 現在の時間を取得する。
     * 
     * @return 現在のカレンダーインスタンス
     */
    public Calendar getCurrentTime() {
        return Calendar.getInstance();
    }

    /**
     * エビフライの画像を取得する。
     * 
     * @return エビフライの画像
     */
    public BufferedImage getEbiFryImage() {
        try {
            File imageFile = new File(EBIFRY_IMAGE_FILENAMES);
            return ImageIO.read(imageFile);
        } catch (IOException e) {
            // 画像の読み込みエラーをハンドリング
            System.err.println("Error loading  image: ");
            e.printStackTrace();
            return null;
        }
    }

    

     /**
     * 画像を指定したサイズにスケーリングする。
     * 
     * @param originalImage 元の画像
     * @param targetWidth   目標の幅
     * @param targetHeight  目標の高さ
     * @return スケーリングされた画像
     */
    public BufferedImage scaleImage(BufferedImage originalImage, int targetWidth, int targetHeight) {
        // アルファチャンネルを考慮してBufferedImageを作成
        BufferedImage scaledImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics g = scaledImage.createGraphics();
        g.drawImage(originalImage, 0, 0, targetWidth, targetHeight, null);
        g.dispose();
        return scaledImage;
    }
}
