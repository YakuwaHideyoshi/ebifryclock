/**
 * EbiFryClockController クラスはモデルとビューを管理する。
 * 
 * @Author: 
 */
public class EbiFryClockController {
    @SuppressWarnings("unused")
    private EbiFryClockModel model;
    private EbiFryClockView view;

    /**
     * コンストラクタ
     * 
     * @param model FlowerClockModel のインスタンス
     * @param view FlowerClockView のインスタンス
     */
    public EbiFryClockController(EbiFryClockModel model, EbiFryClockView view) {
        this.model = model;
        this.view = view;
    }

    /**
     * 時計の表示を開始する。
     */
    public void startClock() {
        view.createAndShowGUI();
    }
}
