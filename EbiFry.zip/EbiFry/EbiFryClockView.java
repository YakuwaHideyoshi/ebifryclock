import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;

/**
* EbiFryClockView クラスはエビフライ時計の表示を管理する。
* 
* @Author: 
*/

public class EbiFryClockView {

    private EbiFryClockModel model;

    /**
     * コンストラクタ
     * 
     * @param model EbiFryClockModel のインスタンス
     */

    public EbiFryClockView(EbiFryClockModel model) {
        this.model = model;
    }

    /**
     * GUI を作成し表示する。
     */
    public void createAndShowGUI() {

        // メインフレームの作成と設定
        JFrame mainFrame = new JFrame("EbiFryClock");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(600, 600);
        
        // キャンバスの作成と描画メソッドの指定
        Canvas canvas = new Canvas() {
            public void paint(Graphics graphics) {
                drawClock(graphics);
            }
        };
        mainFrame.add(canvas);
        mainFrame.setVisible(true);

        // 定期的な再描画を行うタイマータスクの作成とスケジュール
        TimerTask timerTask = new TimerTask() {
            public void run() {
                canvas.repaint();
            }
        };

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(timerTask, 0, 1000);   
    }

    /**
     * エビフライ時計を描画する。
     * 
     * @param graphics Graphics オブジェクト
     */
    public void drawClock(Graphics graphics) {
        Calendar calendar = model.getCurrentTime();
        int hour = calendar.get(Calendar.HOUR);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);

        if (hour == 0) {
            hour = 12;
        }

        BufferedImage EbiFryImage = model.getEbiFryImage();
        if (EbiFryImage != null) {
            // 時針
            drawEbiFryImage(graphics, EbiFryImage, hour * 5 + minute / 12, 50, 10); // 1時間は30度、1分あたりは0.5度
            // 分針
            drawEbiFryImage(graphics, EbiFryImage, minute, 100, 5); // 1分は6度
            // 秒針
            drawEbiFryImage(graphics, EbiFryImage, second, 120, 2); // 1秒は6度
        } else {
            System.err.println("EbiFry image is null:");
        }
    }

     /**
     * エビフライの画像を描画する。
     * 
     * @param graphics      Graphics オブジェクト
     * @param EbiFryImage   エビフライの画像
     * @param timeValue     時間の値
     * @param length        長さ
     * @param width         幅
     */
    public void drawEbiFryImage(Graphics graphics, BufferedImage EbiFryImage, int timeValue, int length, int width) {   // 田中登也
        
        // キャンバスのサイズ
        int canvasWidth = 600;
        int canvasHeight = 600;

        // 画像のスケーリング
        double scale = Math.min((canvasWidth -40) / (double) EbiFryImage.getWidth(), (canvasHeight -40) / (double) EbiFryImage.getHeight());
        int scaledWidth = (int) (EbiFryImage.getWidth() * scale);
        int scaledHeight = (int) (EbiFryImage.getHeight() * scale);
        BufferedImage scaledEbiFryImage = model.scaleImage(EbiFryImage, scaledWidth, scaledHeight);

        // 回転の基準点
        double anchorX = scaledEbiFryImage.getWidth() / 2.0;
        double anchorY = scaledEbiFryImage.getHeight() / 2.0;

        // 回転角度の計算
        double rotateDegree = timeValue * 6.0; // 1分または1秒あたり6度回転
        double rotateRadian = Math.toRadians(rotateDegree);

        // 回転の実行
        AffineTransform transform = AffineTransform.getRotateInstance(rotateRadian, anchorX, anchorY);
        AffineTransformOp transformOp = new AffineTransformOp(transform, AffineTransformOp.TYPE_BICUBIC);

        // 画像の描画
        int imageX = (canvasWidth - scaledEbiFryImage.getWidth()) / 2;
        int imageY = (canvasHeight - scaledEbiFryImage.getHeight()) / 2;

        graphics.drawImage(transformOp.filter(scaledEbiFryImage, null), imageX, imageY, null);
    }
}
